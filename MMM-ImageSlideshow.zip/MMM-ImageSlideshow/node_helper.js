/* global Module */

/* node_helper.js
 * 
 * Magic Mirror
 * Module: MMM-ImageSlideshow
 * 
 * Magic Mirror By Michael Teeuw http://michaelteeuw.nl
 * MIT Licensed.
 * 
 * Module MMM-ImageSlideshow By Adam Moses http://adammoses.com
 * MIT Licensed.
 */
/*WICHTIG für die Nachwelt. Das Grundgerüst ist von der MMM Page
Wenn du wissen willst wo ich Hand angelegt habe suche nach den 
Console.logs
call in the required classes
doppelter Filereader für Facerec und für Beschreibungen
*/
const fs = require('fs');
const rr = fs.createReadStream('xyz.csv');
const ra = fs.createReadStream('face.txt');
var NodeHelper = require("node_helper");
var FileSystemImageSlideshow = require("fs");
var bs="";
var facedetect= false;


// the main module helper create
module.exports = NodeHelper.create({
    // subclass start method, clears the initial config array
    start: function() {
        this.moduleConfigs = [];
    },
    // shuffles an array at random and returns it
    shuffleArray: function(array) {
      var currentIndex = array.length, temporaryValue, randomIndex;
      while (0 !== currentIndex) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
      }
      return array;
    },
    // sort by filename attribute
    sortByFilename: function (a, b) {
        aL = a.filename.toLowerCase();
        bL = b.filename.toLowerCase();
        if (aL > bL) 
			return 1;
		else 
			return -1;
    },
    // checks there's a valid image file extension
    checkValidImageFileExtension: function(filename, extensions) {
        var extList = extensions.split(',');
        for (var extIndex = 0; extIndex < extList.length; extIndex++) {
            if (filename.toLowerCase().endsWith(extList[extIndex]))
                return true;
        }
        return false;
     },
showhit:function(hit){
        //Auslesen der CSV. In dieser Befinden sich die Namen der Bilder
        //und die dazugehörigen Beschreibungen Spalte 3 Dient für den 
        //Preis
        var data=fs.readFileSync('xyz.csv')
        .toString()
        .split('\n')
        .map(e =>e.trim())
        .map(e=>e.split(',').map(e=>e.trim()));
    for(var i=0;i<data.length;i++){
    if(data[i][0]==hit){
        return JSON.stringify(data[i][1]);
        }
        
}
return "Keine Beschreibung vorhanden";

//------------------------------------------

},
    // gathers the image list
    gatherImageList: function(config) {
        var self = this;
        // create an empty main image list
        var imageList = [];
        // for each of the paths specified
        for (var pathIndex = 0; pathIndex < config.imagePaths.length; pathIndex++) {
            var currentPath = config.imagePaths[pathIndex];
            var currentPathImageList = FileSystemImageSlideshow.readdirSync(path = currentPath);
            // for each file in the current path
            if (currentPathImageList.length > 0) {
                // create an empty list for images in the current path
                var currentImageList = [];
                // for each file
                for (var imageIndex = 0; imageIndex < currentPathImageList.length; imageIndex++) {
                    // seperate into path and filename
                    
                    var currentImage = {path: currentPath, filename: currentPathImageList[imageIndex]};
                    //showhit nimmt hier den Filename mit 
                    this.showhit(currentImage.filename)
                    
                    //HIER
                    
                    // check if file has a valid image file extension
                    var isValidImageFileExtension = this.checkValidImageFileExtension(
                                currentImage.filename, 
                                config.validImageFileExtensions);
                    //  if file is valid, add it to the list
                    if (isValidImageFileExtension)
                        currentImageList.push(currentImage);
                }
                // if not set to combine all paths, do random or alphabetical sort
                if (!config.treatAllPathsAsOne) {
                    if (config.randomizeImageOrder)
                        currentImageList = this.shuffleArray(currentImageList);
                    else
                        currentImageList = currentImageList.sort(this.sortByFilename);
                }
                // add current list main list
                imageList = imageList.concat(currentImageList);
            }
        }
        // if set to combine all paths, sort all images randomly or alphabetically by filename
        if (config.treatAllPathsAsOne) {
            if (config.randomizeImageOrder)
                imageList = this.shuffleArray(imageList);
            else
                imageList = imageList.sort(this.sortByFilename);
        }
        // create a file image list combining paths and filenames
        var imageListComplete = [];
        for (var index = 0; index < imageList.length; index++) {
            desc=this.showhit(imageList[index].filename);
            //console.log(desc);
            imageListComplete.push(imageList[index].path + '/' + imageList[index].filename+'!'+desc);
		}
        // return final list
        return imageListComplete;
    },
    

    // subclass socketNotificationReceived, received notification from module
    //---------------------------------------------------------------
    socketNotificationReceived: function(notification, payload) {
        if (notification ==="checkface"){
            var data=fs.readFileSync('/home/pi/Desktop/FaceDect/faces.txt')
            var facestat = data.toString();
            if(facestat == "thereisaface"&&!facedetect){
                this.sendSocketNotification("FACEDETECTED","");
                facedetect=true;
            }else if(facestat == "thereisnoface"&&facedetect){
                this.sendSocketNotification("NOFACEDETECTED","");
                facedetect=false;
            }
            
        }
        
        //--------------------------------------------------------------
        if (notification === "IMAGESLIDESHOW_REGISTER_CONFIG") {
            // add the current config to an array of all configs used by the helper
            this.moduleConfigs.push(payload);
            // this to self
            var self = this;
            // get the image list
            var imageList = this.gatherImageList(payload);
            
            // build the return payload
            var returnPayload = { identifier: payload.identifier, imageList: imageList,Description:this.bs};
            
            //hier
            // send the image list back
            self.sendSocketNotification('IMAGESLIDESHOW_FILELIST', returnPayload );
        }
    },

});
    

//------------ end -------------

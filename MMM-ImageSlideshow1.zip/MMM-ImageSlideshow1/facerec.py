import cv2
import sys
import os
import time

face_cascade = cv2.CascadeClassifier("/home/pi/Desktop/FaceDect/haarcascade_frontalface_default.xml")

cap = cv2.VideoCapture(0)

state = 0;

bigface = 0;

timecount = 0;

print("noface")
f = open("/home/pi/Desktop/FaceDect/faces.txt", "w")
f.write("thereisnoface")
f.close()

while True:
    time.sleep(0.5)
    _, img = cap.read()

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = []

    faces = face_cascade.detectMultiScale(gray, 1.1, 4)

    for (x, y, w, h) in faces:
        if w * h > 22500 :
            bigface = 1
        else:
            bigface = 0


    if len(faces) > 0 and state == 0 and bigface == 1:
        timecount = timecount + 1
        if timecount > 2:
            print("face")
            f = open("/home/pi/Desktop/FaceDect/faces.txt", "w")
            f.write("thereisaface")
            f.close()
            state = 1
            time.sleep(15)


    if len(faces) < 1 and state == 1:
        print("noface")
        f = open("/home/pi/Desktop/FaceDect/faces.txt", "w")
        f.write("thereisnoface")
        f.close()
        state = 0
        timecount = 0
        bigface = 0
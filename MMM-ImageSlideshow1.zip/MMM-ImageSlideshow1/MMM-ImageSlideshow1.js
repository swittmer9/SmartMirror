/* global Module */

/* MMM-ImageSlideshow.js
 * 
 * Magic Mirror
 * Module: MMM-ImageSlideshow
 * 
 * Magic Mirror By Michael Teeuw http://michaelteeuw.nl
 * MIT Licensed.
 */
Module.register("MMM-ImageSlideshow1", {
	 
		defaults: {
        imagePaths: [ 'modules/MMM-ImageSlideshow1/exampleImages' ],
		slideshowSpeed: 10 * 1000,
        fixedImageWidth: 600,
        fixedImageHeight: 350,
        randomizeImageOrder: false,
        treatAllPathsAsOne: false,
        makeImagesGrayscale: false,
        validImageFileExtensions: 'bmp,jpg,gif,png',
		delayUntilRestart: 0,
	},
    	start: function () {
            this.config.identifier = this.identifier;
        this.config.validImageFileExtensions = this.config.validImageFileExtensions.toLowerCase();
        
		this.errorMessage = null;
        if (this.config.imagePaths.length == 0) {
            this.errorMessage = "MMM-ImageSlideshow1: Missing required parameter."
        }
        else {
	    this.descList=[];
            this.imageList = [];
            this.imageIndex = -1;
	    this.decIndex=-1;
            // ask helper function to get the image list
            this.sendSocketNotification('IMAGESLIDESHOW_REGISTER_CONFIG', this.config);
			// do one update time to clear the html
			this.updateDom();
			// set a blank timer
			this.interval = null;
        }
	},
	// Define required scripts.
	getStyles: function() {
        // the css contains the make grayscale code
		return ["imageslideshow.css"];
	},
	showshit:function(){

    },  
       notificationReceived:function(not,payload,sender){
        switch(not){
            case "DOM_OBJECTS_CREATED":
	    //var timer = setInterval(()=>{
	    //this.sendSocketNotification("checkface","");
	//},4000)
	break;
	//-------------------------------------------------------------
	}
	    //-----------------------------------------------------
	    },    
	// the socket handler
	socketNotificationReceived: function(notification, payload) {
		// if an update was received
		var x =true;
		if (notification ==="NOFACEDETECTED"){
		this.sendNotification("MMM-Screencast:RUN-APPNOFACEDETECTED",'')
		
		}
		if (notification ==="FACEDETECTED"){
		this.sendNotification("MMM-Screencast:RUN-APPFACEDETECTED",'')
		
		}
		
		
		
		if (notification === "IMAGESLIDESHOW_FILELIST") {
			// check this is for this module based on the woeid
			if (payload.identifier === this.identifier)
			{
				// set the image list
				var temp=[];
				//Hier wird der String vom Backend bearbeitet 
				//this.imageList = payload.imageList;
				for(var i=0;i<payload.imageList.length;i++){
				temp.push(payload.imageList[i].split("!"));
				this.imageList.push(temp[i][0]);
				this.descList.push(temp[i][1]);
				}

                // if image list actually contains images
                // set loaded flag to true and update dom
                if (this.imageList.length > 0) {
                    this.loaded = true;
                    this.updateDom();
					// set the timer schedule to the slideshow speed			
					var self = this;
					this.interval = setInterval(function() {
						self.updateDom();
						}, this.config.slideshowSpeed);					
                }
			}
		}
    },    
	// Override dom generator.
	getDom: function () {
		var wrapper = document.createElement("div");
        // if an error, say so (currently no errors can occur)
        if (this.errorMessage != null) {
            wrapper.innerHTML = this.errorMessage;
        }
        // if no errors
        else {
            // if the image list has been loaded
            if (this.loaded === true) {
				// if was delayed until restart, reset index reset timer
				if (this.imageIndex == -2) {
					this.imageIndex = -1;
					this.decIndex = -1;
					clearInterval(this.interval);
					var self = this;
					this.interval = setInterval(function() {
						self.updateDom(0);
						}, this.config.slideshowSpeed);						
				}				
                // iterate the image list index
                this.imageIndex += 1;
		this.decIndex += 1;
		
				// set flag to show stuff
				var showSomething = true;
                // if exceeded the size of the list, go back to zero
                if (this.imageIndex == this.imageList.length) {
					// if delay after last image, set to wait
					if (this.config.delayUntilRestart > 0) {
						this.imageIndex = -2;
						this.decIndex = -2;
						wrapper.innerHTML = "&nbsp;";
						showSomething = false;
						clearInterval(this.interval);
						var self = this;
						this.interval = setInterval(function() {
							self.updateDom(0);
							}, this.config.delayUntilRestart);									
					}
					// if not reset index
					else
						this.imageIndex = 0;
						this.decIndex = 0;
				}
				if (showSomething) {
					// create the image dom bit
					var image = document.createElement("img");
					var beschreibung =this.descList[this.decIndex];
					image.setAttribute("id","besch");
					image.onclick = function(){
					alert(beschreibung);
					
					}
					
					// if set to make grayscale, flag the class set in the .css file
					
					if (this.config.makeImagesGrayscale)
						image.className = "desaturate";
					// create an empty string
					var styleString = '';
					// if width or height or non-zero, add them to the style string
					if (this.config.fixedImageWidth != 0)
						styleString += 'width:' + this.config.fixedImageWidth + 'px;';
					if (this.config.fixedImageHeight != 0)
						styleString += 'height:' + this.config.fixedImageHeight + 'px;';
					// if style string has antyhing, set it
					if (styleString != '')
						image.style = styleString;
					// set the image location
					image.src = encodeURI(this.imageList[this.imageIndex]);
					//console.log(this.decIndex);
					//console.log(this.imageIndex);
					// ad the image to the dom
					wrapper.appendChild(image);
								
				}
            }
            else {
                // if no data loaded yet, empty html
                wrapper.innerHTML = "&nbsp;";
            }
        }
        // return the dom
		return wrapper;
	}
});

Module.register("MMM-Test1", {
  defaults: {
      first: "Modul"
    },
  start: function () {
    this.count = 0
    },
  getDom: function() {
    var self=this;
    var element = document.createElement("div")
    element.className = "myContent"
    element.onclick= function(){
    self.sendNotification("ENGLISCH", this.count)
    }
    element.innerHTML = "Mitbring-App (Englisch)"
    return element
  }
 
})

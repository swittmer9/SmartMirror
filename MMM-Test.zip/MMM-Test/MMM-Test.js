Module.register("MMM-Test", {
  defaults: {
      first: "Modul"
    },
  start: function () {
    this.count = 0
    },
  getDom: function() {
    var self=this;
    var element = document.createElement("div")
    element.className = "myContent"
    element.onclick= function(){
    self.sendNotification("DEUTSCH", this.count)
    }
    element.innerHTML = "Mitbring-App (Deutsch)"
    return element

    
    },
})
